# Blinky con freeOSEK y sAPI. 

**El archivo ".oil" debe nombrarse igual que la carpeta del proyecto.**

**No olvidar el paso "make generate" antes de "make" en los proyectos con OSEK.**
