/*
 * dac.h
 *
 *  Created on: Sep 4, 2013
 *      Author: Pablo
 */

#ifndef DAC_H_
#define DAC_H_

void dacInit(void);
void dacWrite(uint32_t v);

#endif /* DAC_H_ */
