#include <stdio.h>
#include <stdlib.h>
#include "SerialManager.h"



int main(void)
{
	printf("Inicio Serial Service\r\n");
	
	
	exit(EXIT_SUCCESS);
	return 0;
}
