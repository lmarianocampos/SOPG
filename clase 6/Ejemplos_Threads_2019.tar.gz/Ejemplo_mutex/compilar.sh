gcc -pthread main_ok.c -o main
