gcc -pthread main.c -o main
