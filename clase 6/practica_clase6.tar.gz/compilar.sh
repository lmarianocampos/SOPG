gcc server_tcp.c ClientData.c -pthread -o server
gcc cliente_tcp.c -o client
